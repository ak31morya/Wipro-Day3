import './App.css';
import UserShow from './components/userShow';
import PostShow from './components/postShow/postShow';
import UserSearch from './components/userSearch/UserSearch';
import EmploySearch from './components/EmploySearch/employSearch';
import EmployInsert from './components/EmployInsert/employInsert';

function App() {
  return (
    <div className="App">
      <UserShow/> <br/>
      <PostShow/> <hr/>
      <UserSearch/> <hr/>
      <EmploySearch/> <hr/>
      <EmployInsert/>
    </div>
  );
}

export default App;
